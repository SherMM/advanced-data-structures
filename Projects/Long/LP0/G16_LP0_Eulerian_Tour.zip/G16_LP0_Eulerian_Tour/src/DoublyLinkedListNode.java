
/**
 * 
 * Class represents a node in the doubly linked list.
 * 
 * 
 * @author G16
 *
 * @param <T>
 */

public class DoublyLinkedListNode<T> {
		
		public T value;
		public DoublyLinkedListNode<T> next;
		public DoublyLinkedListNode<T> prev;
		
		public DoublyLinkedListNode(T value) {
			
			this.value = value;
			this.next = null;
			this.prev = null;
		}
		
		public String toString() {
			
			return value.toString();
		}
}
