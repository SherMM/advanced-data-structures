import java.util.LinkedList;
import java.util.Queue;

/**
 * Class that implements method to check if the given graph is eulerian or not.
 * 
 * 
 * @author G16
 *
 */

public class EulerianGraphValidator {

	/*
	 * Status of graph validation based on the possible outcomes that the given graph may be
	 * disconnected or eulerian graph or eulerian path or not an eulerian graph
	 * 
	 * 
	 */
	public enum GraphStatus { NOTCONNECTED, EULERIANGRAPH, EULERIANPATH, NONEULERIANGRAPH };
	
	/**
	 * reset the graph parameters.
	 * 
	 * 
	 * 
	 */
	
	private static void resetGraph(Graph g) {

		for (Vertex v : g) {

			v.parent = null;
			v.seen = false;
			v.distance = 0;
		}
	}

	
	/**
	 * Checks if the graph is connected by doing a BFS and checking if the number of visited nodes is equal 
	 * to the total number of nodes in the graph.
	 * 
	 * 
	 * 
	 * @return
	 */
	private static boolean isGraphConnected(Graph g) {
		
		int componentSize = 0;
		Vertex vertex = g.verts.get(1);
		Queue<Vertex> queue = new LinkedList<Vertex>();

		resetGraph(g);
		
		vertex.seen = true;
		queue.add(vertex);
		
		while (!queue.isEmpty()) {
			
			Vertex v = queue.poll();
			componentSize += 1;
						
			for(Edge e : v.Adj) {
				
				Vertex u = e.otherEnd(v);
				
				if (!u.seen) {
					
					u.seen = true;
					queue.add(u);
				}
			}
		}

		return (componentSize == (g.verts.size() - 1));
	}

	/**
	 * Checks if the graph is eulerian
	 * 
	 * 
	 * 
	 * @param g
	 * @return true if eulerian else false;
	 */
	
	private static boolean checkIfEulerianGraphExists(Graph g) {
		
		for (Vertex v : g) {
			
			if (v.Adj.size() % 2 == 1) {
				
				return false;
			}
		}
		return true;
	}
	
	/**
	 * checks if the eulerian path exists in the graph
	 * 
	 * 
	 * @param g
	 * @return true if eulerian path exists else false;
	 */
	
	
	private static boolean checkIfEulerianPathExists(Graph g) {
		
		int oddDegreeVerticesCount = 0;
		
		for (Vertex vertex : g) {
			
			if (vertex.Adj.size() % 2 == 1) {
				
				oddDegreeVerticesCount += 1;
			}
		}
		
		if (oddDegreeVerticesCount != 2) {
			
			return false;
		}
					
		return true;
	}
	
	
	/**
	 * checks and returns the status of the graph
	 * 
	 * 
	 * @param g
	 * @return NOTCONNECTED, EULERIANGRAPH, EULERIANPATH, NONEULERIANGRAPH;
	 */
	
	public static GraphStatus getGraphType(Graph g) {
		
		if (!isGraphConnected(g)) {
			
			return GraphStatus.NOTCONNECTED;
		} else if (checkIfEulerianGraphExists(g)) {
			
			return GraphStatus.EULERIANGRAPH;
		} else if (checkIfEulerianPathExists(g)) {
			
			return GraphStatus.EULERIANPATH;
		} else {
			
			return GraphStatus.NONEULERIANGRAPH;
		}
	}
}
