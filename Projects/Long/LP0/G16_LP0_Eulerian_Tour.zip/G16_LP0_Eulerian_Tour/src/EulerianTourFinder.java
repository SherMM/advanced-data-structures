import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
/**
 * Implements the logic to find an eulerian tour of a graph using hierholzer's algorithm.
 * 
 * @author G16
 *
 */
public class EulerianTourFinder {

	
	/**
	 * Creates a doubly linked list of vertices which contain doubly linked list of their corresponding edges.
	 * This list serves as the input to the algorithm. Vertices are wrapped in EulerianVertex Object 
	 * and Edges are wrapped in EulerianEdge class.
	 * 
	 * 
	 * @param g
	 * @return
	 */
	private static DoublyLinkedList<EulerianVertex> buildEulerianVertexList(Graph g) {

		DoublyLinkedList<EulerianVertex> eulerianVertices = new DoublyLinkedList<EulerianVertex>();

		for (Vertex vertex : g) {

			EulerianVertex eulerianVertex = new EulerianVertex(vertex);
			DoublyLinkedListNode<EulerianVertex> node = new DoublyLinkedListNode<EulerianVertex>(
					eulerianVertex);
			eulerianVertex.associatedNode = node;
			eulerianVertices.add(node);
		}

		for (Vertex vertex : g) {

			for (Edge edge : vertex.Adj) {

				Vertex otherEnd = edge.otherEnd(vertex);

				if (vertex.name < otherEnd.name) {

					EulerianEdge eulerianEdge = new EulerianEdge(edge,vertex.associatedNode, 
							otherEnd.associatedNode);

					EulerianEdge eulerianAssociatedEdge = new EulerianEdge(edge,
							vertex.associatedNode,
							otherEnd.associatedNode);

					DoublyLinkedListNode<EulerianEdge> eulerianEdgeNode = new DoublyLinkedListNode<EulerianEdge>(eulerianEdge);
					DoublyLinkedListNode<EulerianEdge> eulerianAssociatedEdgeNode = new DoublyLinkedListNode<EulerianEdge>(
							eulerianAssociatedEdge);

					eulerianEdge.setAssociatedEulerianEdge(eulerianAssociatedEdgeNode);
					eulerianAssociatedEdge.setAssociatedEulerianEdge(eulerianEdgeNode);

					vertex.associatedNode.addEdge(eulerianEdgeNode);
					otherEnd.associatedNode.addEdge(eulerianAssociatedEdgeNode);
				}
			}
		}

		return eulerianVertices;
	}

	/**
	 * Remove Eulerian Vertex from the doubly linked list if it has no unused Edges
	 * 
	 * 
	 */
	
	private static void removeEulerianVertex(DoublyLinkedList<EulerianVertex> eulerianVertices,
			EulerianVertex eulerianVertex) {
		
		if (!eulerianVertex.hasEulerianEdges()) {

			eulerianVertices.remove(eulerianVertex.associatedNode);

			eulerianVertex.associatedNode = null;

		}
	}
	
	/**
	 * 
	 * Removes the Eulerian edge from the doubly linked eulerian vertex.
	 * if the vertex has no eulerian edge, it is then removed from the doubly linked list itself.
	 * 
	 * 
	 * @param eulerianVertices
	 * @param eulerianVertex
	 * @param eulerianEdgeNode
	 */
	
	private static void removeEulerianEdge(DoublyLinkedList<EulerianVertex> eulerianVertices,
			EulerianVertex eulerianVertex, DoublyLinkedListNode<EulerianEdge> eulerianEdgeNode) {

		try {

			eulerianVertex.removeEulerianEdge(eulerianEdgeNode);

			removeEulerianVertex(eulerianVertices, eulerianVertex);

			eulerianVertex = eulerianEdgeNode.value.otherEnd(eulerianVertex);
			eulerianEdgeNode = eulerianEdgeNode.value.getAssociatedEulerianEdge();

			eulerianVertex.removeEulerianEdge(eulerianEdgeNode);

			removeEulerianVertex(eulerianVertices, eulerianVertex);

		} catch (Exception e) {

			System.out.println("in function: " + e.toString());
		}
	}
	
	/**
	 * Gets a path between two vertices in the list containing eulerian vertices with eulerian edges.
	 * Also removes those edges in the path from the list.
	 * 
	 * 
	 * @param eulerianVertices
	 * @param start
	 * @param end
	 * @return
	 */

	private static DoublyLinkedList<EulerianEdge> getPath(DoublyLinkedList<EulerianVertex> eulerianVertices,
			EulerianVertex start, EulerianVertex end) {

		DoublyLinkedList<EulerianEdge> path = new DoublyLinkedList<EulerianEdge>();

		if (start.hasEulerianEdges()) {

			EulerianVertex currentVertex = start;

			do {

				DoublyLinkedListNode<EulerianEdge> eulerianEdgeNode = currentVertex.eulerianEdges.getFirst();
				EulerianEdge eulerianEdge = eulerianEdgeNode.value;

				removeEulerianEdge(eulerianVertices, currentVertex, eulerianEdgeNode);
				path.add(eulerianEdgeNode);
				currentVertex = eulerianEdge.otherEnd(currentVertex);
			} while (currentVertex != end);
		}

		return path;
	}

	
	/**
	 * Adds the list of nodes containing edges  to the unprocessed queue. Used in findEulerTour function.
	 * 
	 * @param unprocessedNodes
	 * @param currentTour
	 */
	
	private static void addNodestoProcessingQueue(Queue<DoublyLinkedListNode<EulerianEdge>> unprocessedNodes,
			DoublyLinkedList<EulerianEdge> currentTour) {

		for (DoublyLinkedListNode<EulerianEdge> node : currentTour) {

			unprocessedNodes.add(node);
		}
	}
	
	/**
	 * Finds all the circuits starting at the vertex and adds the same to the euler tour output.
	 * Also adds the vertices to the queue of unprocessed vertices for further processing.
	 * 
	 * 
	 * @param eulerianVertices
	 * @param eulerianVertex
	 * @param unprocessedNodes
	 * @param node
	 * @param eulerTour
	 */

	private static void addCircuit(DoublyLinkedList<EulerianVertex> eulerianVertices, EulerianVertex eulerianVertex,
			Queue<DoublyLinkedListNode<EulerianEdge>> unprocessedNodes, DoublyLinkedListNode<EulerianEdge> node, 
			DoublyLinkedList<EulerianEdge> eulerTour) {
		
		while (eulerianVertex.hasEulerianEdges()) {

			DoublyLinkedList<EulerianEdge> currentTour = getPath(eulerianVertices, eulerianVertex,
					eulerianVertex);
			addNodestoProcessingQueue(unprocessedNodes, currentTour);
			
			if(node.next != null && node.next.value != null 
					&& node.next.value.edge.contains(eulerianVertex.vertex) ) { //check where to place the circuit position.
				
			
				eulerTour.appendAfter(node, currentTour);
			} else {
				
				eulerTour.appendBefore(node, currentTour);
			}
		}
	}
	
	/**
	 * Finds an Eulerian tour in the graph using HierHolzer's Algorithm.
	 * This function is overloaded private function of its corresponding public function.
	 * Input is the list of vertices with eulerian edges and an initial path of the list that connects start
	 * and end vertices of the eulerian tour.
	 * 
	 * @param eulerianVertices
	 * @param eulerTour
	 */
	
	private static void findEulerTour(DoublyLinkedList<EulerianVertex> eulerianVertices,
			DoublyLinkedList<EulerianEdge> eulerTour) {

		if (eulerianVertices.isEmpty()) {

			return;
		}

		Queue<DoublyLinkedListNode<EulerianEdge>> unprocessedNodes = new LinkedList<DoublyLinkedListNode<EulerianEdge>>();

		addNodestoProcessingQueue(unprocessedNodes, eulerTour);

		while (!unprocessedNodes.isEmpty()) {

			DoublyLinkedListNode<EulerianEdge> node = unprocessedNodes.poll();
			EulerianEdge edge = node.value;
			addCircuit(eulerianVertices, edge.from.value, unprocessedNodes, node, eulerTour);
			addCircuit(eulerianVertices, edge.to.value, unprocessedNodes, node, eulerTour);
		}

		return;
	}
	
	/**
	 * Finds an Eulerian tour in the graph using HierHolzer's Algorithm.
	 * 
	 * 
	 * @param g
	 * @return
	 * @throws Exception 
	 */
	
	public static DoublyLinkedList<EulerianEdge> findEulerTour(Graph g) {

		Vertex start = null, end = null;

		switch (EulerianGraphValidator.getGraphType(g)) {

		case NOTCONNECTED:
		case NONEULERIANGRAPH:

			return null;

		case EULERIANGRAPH:

			start = g.verts.get(1);
			end = start;
			break;

		case EULERIANPATH:

			for (Vertex vertex : g) {

				if (vertex.Adj.size() % 2 == 1) {

					if (start == null) {

						start = vertex;
					} else {

						end = vertex;
					}
				}
			}

			break;

		default:
			return null;
		}

		DoublyLinkedList<EulerianVertex> eulerianVertices = buildEulerianVertexList(g);

		DoublyLinkedList<EulerianEdge> eulerTour = getPath(eulerianVertices, start.associatedNode,
				end.associatedNode); //gets the initial path of Euler tour from start to end;

		findEulerTour(eulerianVertices, eulerTour);
	
		
		return eulerTour;
	}

	/**
	 * Finds the start vertex of the eulerian tour;
	 * Note: This method does not verifies if the tour is valid  or not.
	 * 
	 * 
	 * @param tour
	 * @return
	 */
	
	public static Vertex getStartVertexOfEulerTour(DoublyLinkedList<EulerianEdge> tour) {
		
		Iterator<DoublyLinkedListNode<EulerianEdge>> tourIterator =  tour.iterator();
		Edge firstEdge = tourIterator.next().value.edge;
		Edge secondEdge = tourIterator.next().value.edge;
		
		return secondEdge.contains(firstEdge.From) ? firstEdge.To : firstEdge.From;
	}
	/**
	 * Driver function
	 * 
	 * 
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		PrintWriter logFile = null;
		
		try {
			long startTime, endTime;
			
			logFile = new PrintWriter(new BufferedWriter(new FileWriter("Logs.txt", true))); //opens log file in append mode

			logFile.println("Process started...");
			
			Graph g = Graph.readGraph(args.length > 0 ? new Scanner(new File(args[0])) : new Scanner(System.in), false);
			
			logFile.println("Input Graph successfully read...");

			startTime  = System.nanoTime();
			
			DoublyLinkedList<EulerianEdge> tour = findEulerTour(g);
			
			endTime = System.nanoTime();
			
			logFile.println("Tour Finder Process completed");
			
			logFile.println(("Execution Time : " + ((float)(endTime - startTime)) / 1000000000) + " seconds");
			
			if (tour == null) {
				
				System.out.println("Graph is not Eulerian");
				logFile.println("Verification Skipped as the Graph is not Eulerian..");
			} else {
			
				if (!EulerianTourVerifier.verifyTour(g, tour, getStartVertexOfEulerTour(tour))) {
					
					logFile.println("Verification Failed..");
				} else  {
					
					logFile.println("Verification success..");
				}
				
				for (EulerianEdge eulerianEdge : tour.asValues()) {
	
					System.out.println(eulerianEdge.edge);
				}
			}
			
			logFile.println();
			
		} catch (Exception e) {

		  if (logFile != null) { 
			  
			  logFile.println(e.toString());
		  } else {
			  
			  System.out.println(e.toString());
		  }
		  
		} finally {
			
			if (logFile != null) { 
				
				logFile.close(); 
			}
		}
	}
}