
/**
 * Wrapper class for the vertex. it contains the list of associated eulerian edges.
 * It is used in doubly linked list.
 * Also contains a member to store the doubly linked list node in which the current object is stored.
 * 
 * 
 * @author G16
 *
 */

public class EulerianVertex {

	Vertex vertex;
	public DoublyLinkedListNode<EulerianVertex> associatedNode;
	public DoublyLinkedList<EulerianEdge> eulerianEdges;
	
	/**
	 * Constructor
	 * 
	 * @param vertex
	 */
	
	public EulerianVertex(Vertex vertex) {
	
		this.vertex = vertex;
		this.vertex.associatedNode = this;
		this.eulerianEdges = new DoublyLinkedList<EulerianEdge>();
	}
	
	/**
	 * add an edge to the vertex;
	 * 
	 * 
	 * @param eulerianEdge
	 */
	
	public void addEdge(DoublyLinkedListNode<EulerianEdge> eulerianEdge) {
		
		this.eulerianEdges.add(eulerianEdge);
	}

	
	/**
	 * checks if the vertex class contains any eulerian edge.
	 * 
	 * 
	 * @return
	 */
	public boolean hasEulerianEdges() {
		
		return !this.eulerianEdges.isEmpty();
	}
	
	/**
	 * Removes the eulerian edge from the given node which contains Vertex.
	 * 
	 * 
	 * @param eulerianEdgeNode
	 */
	
	public void removeEulerianEdge(DoublyLinkedListNode<EulerianEdge> eulerianEdgeNode) {
		
		try {
			
			EulerianVertex otherVertex = eulerianEdgeNode.value.otherEnd(this);
			
			otherVertex.eulerianEdges.remove(eulerianEdgeNode.value.getAssociatedEulerianEdge());
			this.eulerianEdges.remove(eulerianEdgeNode);

		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
	/**
	 * String representation of the class.
	 * 
	 * 
	 */
	
	@Override
	public String toString() {
		return "EulerianVertex [vertex=" + vertex + ", EulerianEdges=" + eulerianEdges + "]";
	}
}
