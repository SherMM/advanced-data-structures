import java.util.Iterator;

/**
 * Generic Doubly Linked List class which has special functions such as appending a list to before or after a node in another list.
 * It also allows Concurrent Modifications to the list while traversing the same along with removal operation in constant time.
 * 
 * @author G16
 *
 * @param <T>
 */

public class DoublyLinkedList<T> implements Iterable<DoublyLinkedListNode<T>> {

	public DoublyLinkedListNode<T> head;
	public DoublyLinkedListNode<T> tail;
	
	public DoublyLinkedList() {
		
		head = new DoublyLinkedListNode<T>(null);
		tail = head;
	}
	
	/**
	 * Adds a node to the linked list.
	 * 
	 * @param e
	 */
	
	public void add(DoublyLinkedListNode<T> e) {
		
		tail.next = e;
		e.prev = tail;
		tail = tail.next;
	}
	
	/**
	 * appends the list before the node of the calling list.
	 * 
	 * 
	 * @param node
	 * @param list
	 */
	
	public void appendBefore(DoublyLinkedListNode<T> node, DoublyLinkedList<T> list) {
		
		if (!list.isEmpty()) {
	
			node.prev.next = list.head.next;
			list.head.next.prev = node.prev;
			node.prev = list.tail;
			list.tail.next = node;
		}
		list.head.next = null;
		list.tail = null;
	}

	
	/**
	 * appends the list after the node of the calling list.
	 * 
	 * 
	 * 
	 * @param node
	 * @param list
	 */
	
	public void appendAfter(DoublyLinkedListNode<T> node, DoublyLinkedList<T> list) {
		
		if (!list.isEmpty()) {
	
			if (node.next != null) {
				
				node.next.prev = list.tail;
				list.tail.next = node.next;
			}

			node.next = list.head.next;
			list.head.next.prev = node;

			if (list.tail.next == null) {
				
				this.tail = list.tail;
			}
			list.head.next = null;
			list.tail = null;
		}
		
	}
	
	/**
	 * removes the node from the list
	 * 
	 * 
	 * 
	 * @param e
	 */
	
	public void remove(DoublyLinkedListNode<T> e) {

		try {
			if (e == null || (e.prev == null && e.next == null)) {
				
				return;
			}
			
			e.prev.next = e.next;
			
			if (e !=  tail) {

				e.next.prev = e.prev;
			} else {
				
				tail = e.prev;
			}

			e.prev = null;
			e.next = null;
		} catch (Exception ex) {
			
			System.out.println(ex.toString());
		}
	
		
	}
	
	/**
	 * Checks if the list is empty
	 * 
	 * 
	 * @return true if empty else false;
	 */
	
	public boolean isEmpty() {
		
		return this.head == tail;
	}
	
	public String toString() {
		
		String result = "";
		DoublyLinkedListNode<T> node = head.next;
		
		while (node != null) {
			
			result = result + node.toString() + " ";
			node = node.next;
		}
		
		return result;
	}

	
	/**
	 * returns the iterator to the calling list.
	 * 
	 * 
	 */
	public Iterator<DoublyLinkedListNode<T>> iterator() {

		return new DoublyLinkedListIterator();

	}
	
	public Iterable<T> asValues() {
		return new Iterable<T>() {

			@Override
			public Iterator<T> iterator() {

				return new ValueIterator();
			}
			
		};
		
	}
	
	/**
	 * Iterator class for the doubly linked list.
	 * 
	 * 
	 * @author G16
	 *
	 */
	private class DoublyLinkedListIterator implements Iterator<DoublyLinkedListNode<T>> {

		private DoublyLinkedListNode<T> node;
		
		
		public  DoublyLinkedListIterator() {

			node = head;
		}
		
		@Override
		public boolean hasNext() {

			return node.next != null;
		}

		@Override
		public DoublyLinkedListNode<T> next() {
			
			if (hasNext()) {
				
				node = node.next;
				return node;
			}
			
			return null;
		}
		
	}
	
	/**
	 * Iterator class for the doubly linked list.
	 * 
	 * 
	 * @author G16
	 *
	 */
	private class ValueIterator implements  Iterator<T> {

		DoublyLinkedListIterator doublyLinkedListIterator;
 		public ValueIterator() {
			
			doublyLinkedListIterator = new DoublyLinkedListIterator();
		}
		@Override
		public boolean hasNext() {

			return doublyLinkedListIterator.hasNext();
		}

		@Override
		public T next() {
	
			return doublyLinkedListIterator.hasNext() ? doublyLinkedListIterator.next().value : null;
		}

	}
	/**
	 * Gets the first node from the list.
	 * 
	 * 
	 * @return
	 */
	
	public DoublyLinkedListNode<T> getFirst() {
		
		return this.head.next;
	}
}
