
/**
 * This class implements the function to verify if the given tour is eulerian or not for a graph.
 * 
 * 
 * @author G16
 *
 */


public class EulerianTourVerifier {


	/**
	 * Initialize the given graph
	 * 
	 * 
	 * @param g
	 */
	private static void initializeGraphParameters(Graph g) {
		
		for (Vertex vertex : g) { 
			
			vertex.seen = false;
			
			for (Edge edge : vertex.Adj) {
				
				edge.seen = false;
			}
		}
	}
	
	/**
	 * Initialize the edges of the given tour
	 * 
	 * @param tour
	 */
	
	private static void initializeTourParameters(DoublyLinkedList<EulerianEdge> tour) {
		
		for(EulerianEdge eulerianEdge : tour.asValues()) {
			
			eulerianEdge.edge.seen = false;
		}
	}
	
	/**
	 * Gets the count of edges of a graph whose edge.seen parameter equals the boolean value specified
	 * 
	 * @param g
	 * @param seen
	 * @return count of edges
	 */
	
	private static int getCountOfEdges(Graph g, boolean seen) {
		
		int edgeCount = 0;
		
		for (Vertex vertex : g) { 

			for (Edge edge : vertex.Adj) {
				
				if(edge.seen == seen) {
				
					edgeCount++;
				}
			}
		}
		
		return edgeCount;
	}
	
	/**
	 * Verifies if the tour is eulerian with respect to the graph.
	 * 
	 * 
	 * @param g - graph
	 * @param tour - tour
	 * @param start - start vertex of the tour
	 * @return
	 */
	
	public static boolean verifyTour(Graph g, DoublyLinkedList<EulerianEdge> tour, Vertex start) {
		
		int noOfUnSeenEdgesCount = 0;
		Vertex currentVertex = start;

		// initialize graph's seen parameter of vertices and edges to false
		
		initializeGraphParameters(g);
		initializeTourParameters(tour);	
		noOfUnSeenEdgesCount = getCountOfEdges(g, false);	// count of edges of graph
		
		for(EulerianEdge eulerianEdge : tour.asValues()) {
			
			Edge edge = eulerianEdge.edge;
			
			if(edge.seen == true) {                         // edge is traversed more than once. return false;			

				return false;
			}
			
			if (edge.contains(currentVertex)) {            // check for path continuation.
				
				currentVertex.seen = true;
				currentVertex = edge.otherEnd(currentVertex);	
			} else {                                       // the path is disconnected. return false;

				return false;
			}
			

			edge.seen = true;
		}
		
		// check if all the vertices have been visited.
		
		for(Vertex vertex : g) {		
			
			if (vertex.seen == false) { 
				
				return false;
			}
		}
		
		// check if all edges of the graph have been visited
		return (noOfUnSeenEdgesCount == getCountOfEdges(g, true));
	}
}
