/**
 * 
 * This class acts as a wrapper for edges of a graph. It is added to the corresponding EulerianVertex Object.
 * Also has a link to the doubly linked list node.
 * 
 * 
 * @author G16
 *
 */
public class EulerianEdge {

	public Edge edge;
	public DoublyLinkedListNode<EulerianVertex> from; 
	public DoublyLinkedListNode<EulerianVertex> to; 
	private DoublyLinkedListNode<EulerianEdge> associatedEulerianEdge;
	
	public EulerianEdge(Edge edge, EulerianVertex from, EulerianVertex to) {
		
		this.edge = edge;
		this.from = from.associatedNode;
		this.to = to.associatedNode;
	}
	
	/**
	 * Get the Other Vertex of the Edge for a given vertex;
	 * 
	 * @param eulerianVertex
	 * @return
	 */
	
	public EulerianVertex otherEnd(EulerianVertex eulerianVertex) {
		
		if (eulerianVertex == from.value) {
			
			return to.value;
		} else {
			
			return from.value;
		}
	}

	/**
	 * Get the associated doubly linked list node of the eulerian edge.
	 * 
	 * 
	 * @return
	 */
	
	public DoublyLinkedListNode<EulerianEdge> getAssociatedEulerianEdge() {
		return associatedEulerianEdge;
	}

	
	/**
	 * Set the associated doubly linked list node to which the eulerian edge belongs to.
	 *
	 * @param associatedEdge
	 */
	public void setAssociatedEulerianEdge(DoublyLinkedListNode<EulerianEdge> associatedEulerianEdge) {
		this.associatedEulerianEdge = associatedEulerianEdge;
	}

	/**
	 * String representation of the eulerian edge
	 * 
	 */
	@Override
	public String toString() {
		return "EulerianEdge [edge=" + edge + "]";
	}
}
