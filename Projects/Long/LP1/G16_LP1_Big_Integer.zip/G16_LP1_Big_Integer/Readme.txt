Project Description:
--------------------

http://www.utdallas.edu/~rbk/teach/2016s/projects/lp1-6301-2016s.html

Input format:
------------

As specified in project description link. (Level 3)

Output format:
--------------
As specified in project description link. (Level 3).


Sample input:
-------------

1 a=2
2 a=a+3*4^2^3!  # equivalent to a=a+(3*(4^(2^(3!)))).
                # assigns 1020847100762815390390123822295304634370 to a.
3 a

Sample output:
--------------

1020847100762815390390123822295304634370
   
Solution:
---------

Driver Class: Main.java. (Base to be set via command line argument in Main.java)
             -----------