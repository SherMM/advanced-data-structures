
/**
 * 
 * Markable interface. Used to represent Operand, Operator Objects of the Instruction.
 * 
 * @author G16 - Vasudev Ravindran & Ian Laurain
 *
 */
public interface Token {

}
