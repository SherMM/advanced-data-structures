/** Java example to illustrate the use of hashing with user defined classes
 *  @author rbk
 */
import java.util.*;

public class HashingTest {
    static int tableSize = 16;
    Set<Triple> s;
    Map<Triple,String> m;
    Triple x,y,z;

    HashingTest() {
	s = new HashSet<>();
	m = new HashMap<>();
    }

    void initialize(Triple t1, Triple t2, Triple t3) {
	x = t1;  y = t2;  z = t3;
	s.clear();
	s.add(x);  s.add(y);  s.add(z);
	m.clear();
	m.put(x, "x");  m.put(y, "y");  m.put(z, "z");
    }

    void print() {
	System.out.println("Contents of hash set:");
	for(Triple t: s) { System.out.println(t); }
	System.out.println("Contents of hash map:");
	for(Map.Entry<Triple, String> entry: m.entrySet()) {
	    System.out.println(entry.getValue() + ": " + entry.getKey());
	}
	System.out.println("Hashcodes of x,y,z: " + x.hashCode() + " " + y.hashCode() + " " + z.hashCode());
	if(x != y) { System.out.println("x != y"); }
	if(!x.equals(y)) { System.out.println("x.equals(y) is also false"); }
	else { System.out.println("x.equals(y) is true"); }
    }

    class Triple {
	int a, b;  String c;
	Triple(int a, int b, String c) {
	    this.a = a;
	    this.b = b;
	    this.c = c;
	}
	public String toString() { return "|" + a + "|" + b + "|" + c + "|"; }
    }

    public static void hashTest1() {
	System.out.println("\nHashing on Integer class (Table size: 16):\nInteger\tHashcode    Mod n\tIndex");
	for(int i=1; i<=10; i++) {
	    Integer k = new Integer(i*tableSize+65536);
	    System.out.println(k + "\t" + k.hashCode() + "\t      " + k.hashCode()%tableSize + "\t\t  " + hash(k.hashCode()));
	}

	System.out.println("\nNew integer 65600 has hash code: " + new Integer(65600).hashCode());
    }

    /* Output of hashTest1:
       Hashing on Integer class (Table size: 16):
       Integer	Hashcode    Mod n	Index
       65552	65552	      0		  0
       65568	65568	      0		  3
       65584	65584	      0		  2
       65600	65600	      0		  5
       65616	65616	      0		  4
       65632	65632	      0		  7
       65648	65648	      0		  6
       65664	65664	      0		  8
       65680	65680	      0		  9
       65696	65696	      0		  10

       New integer 65600 has hash code: 65600
    */


    void hashTest2() {
	System.out.println("\nHash test2 (Triple):");
	initialize(new Triple(2, 5, "Frayed Knot"), new Triple(2, 5, "Frayed Knot"), new Triple(2, 5, "Frayed Knot"));
	print();
    }
    /* Output of hashTest2:
       Hash test2 (Triple):

       Contents of hash set:
       |2|5|Frayed Knot|
       |2|5|Frayed Knot|
       |2|5|Frayed Knot|

       Contents of hash map:
       x: |2|5|Frayed Knot|
       y: |2|5|Frayed Knot|
       z: |2|5|Frayed Knot|
 
       Hashcodes of x,y,z: 1762198397 1321482602 882214540
       x != y
       x.equals(y) is also false
    */

    class TripleWithEquals extends Triple {
	TripleWithEquals(int a, int b, String s) { super(a,b,s); }

	@Override
	public boolean equals(Object another) {
	    double threshold = 1e-6;
	    if(another == null) return false;
	    if(this == another) return true;
	    TripleWithEquals other = (TripleWithEquals) another;
	    if(this.a == other.a && this.b == other.b && this.c.equals(other.c)) {
		return true;
	    } else {
		return false;
	    }
	}
    }

    void hashTest3() {
	System.out.println("\nHash test3 (TripleWithEquals):");
	initialize(new TripleWithEquals(3, 6, "Afraid not"), new TripleWithEquals(3, 6, "Afraid not"), new TripleWithEquals(3, 6, "Afraid not"));
	print();
    }
    /* Output of hashTest3:
       Hash test3 (TripleWithEquals):

       Contents of hash set:
       |3|6|Afraid not|
       |3|6|Afraid not|
       |3|6|Afraid not|

       Contents of hash map:
       y: |3|6|Afraid not|
       z: |3|6|Afraid not|
       x: |3|6|Afraid not|

       Hashcodes of x,y,z: 1815075761 973109492 1963260139
       x != y
       x.equals(y) is true
    */

    class TripleCorrected extends TripleWithEquals {
	TripleCorrected(int a, int b, String s) { super(a,b,s); }

	@Override
	public int hashCode() {
	    int h1 = new Integer(this.a).hashCode();
	    int h2 = new Integer(this.b).hashCode();
	    int h3 = this.c.hashCode();
	    // this is not a good hash function
	    return h1*31*31 + h2*31 + h3;
	}
    }

    void hashTest4() {
	System.out.println("\nHash test4 (TripleCorrected):");
	initialize(new TripleCorrected(4, 7, "Yes!"), new TripleCorrected(4, 7, "Yes!"), new TripleCorrected(4, 7, "Yes!"));
	s.add(new TripleCorrected(4, 7, "One more"));
	print();	
    }
    /* Output of hashTest4:
       Hash test4 (TripleCorrected):

       Contents of hash set:
       |4|7|Yes!|
       |4|7|One more|

       Contents of hash map:
       z: |4|7|Yes!|

       Hashcodes of x,y,z: 2756119 2756119 2756119
       x != y
       x.equals(y) is true
    */

    /** Borrowed from Java's HashMap:
     *  Applies a supplemental hash function to a given hashCode, which defends
     *  against poor quality hash functions. This is critical because HashMap
     *  uses power-of-two length hash tables, that otherwise encounter
     *  collisions for hashCodes that do not differ in lower bits.
     *  Note: Null keys always map to hash 0, thus index 0.
     */
    static int hash(int h) {
	// This function ensures that hashCodes that differ only by
	// constant multiples at each bit position have a bounded
	// number of collisions (approximately 8 at default load factor).
	h ^= (h >>> 20) ^ (h >>> 12);
	h = (h ^ (h >>> 7) ^ (h >>> 4));
	return h % tableSize;
    }

    public static void main(String[] args) {
	HashingTest t = new HashingTest();
	hashTest1();
	t.hashTest2();
	t.hashTest3();
	t.hashTest4();
    }
}
