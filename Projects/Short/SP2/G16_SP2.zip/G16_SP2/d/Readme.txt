Problem statement:
------------------

Given a graph, find an odd-length cycle and return it.
   If the graph is bipartite, return null

   
Solution:
---------

   Algorithm: run BFS.  If no edge of G connects two nodes at the same
   level, then the graph is bipartite and has no odd-length cycle.
   If two nodes u and v at the same level are connected by edge (u,v),
   then an odd-length cycle can be found by combining the edge (u,v)
   with the paths from u and v to their least common ancestor in the BFS tree.
   If g is not connected, this is repeated in each component.

The following class has been implemented for performing the above algorithm.

FindOddLengthCycle.java (this class requires Graph, Vertex and Edge Classes.)

Input:
------

Input graph can be provided as either as file name in command line argument or throught console using Graph.readgraph function format.

Sample Output:
--------------

List of vertices in an odd length cycle of given graph : [2, 1, 3]


Test Results:
--------------

Test case #1: (If the entire graph is of odd length cycle)
-------------

3 3
1 2 1
2 3 1
3 1 1

List of vertices in an odd length cycle of given graph : [2, 1, 3]

Test case #2: (If the entire graph is disconnected or no edges)
-------------

1 0

List of vertices in an odd length cycle of given graph : null

Test case #3: (If the entire graph is of even length cycle)
-------------
4 4
1 2 1
2 3 1
3 4 1
4 1 1

List of vertices in an odd length cycle of given graph : null


Test case #4: (If the entire graph is of odd length cycle with length > 3)
-------------

5 5
1 2 1
1 3 1
2 4 1
3 5 1
4 5 1

List of vertices in an odd length cycle of given graph : [4, 2, 1, 3, 5]

Test case #5: (If the entire graph is multiple components and an odd length cycle is present in one of the components.)
-------------
7 7
1 2 1
2 6 1
6 7 1
7 1 1
3 4 1
4 5 1
5 3 1


List of vertices in an odd length cycle of given graph : [4, 3, 5]
