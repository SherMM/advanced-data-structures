import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 * This class implements logic to find an odd length cycle in a graph.
 * 
 * 
 * 
 * @author G16
 *
 */

public class FindOddLengthCycle {

	Graph g;
	
	/**
	 * Given two vertices, this function gets all the other vertices in the cycle that encloses them.
	 * 
	 * 
	 * @param u
	 * @param v
	 * @return
	 */
	
	
	private List<Vertex> getAllVerticesOfCycle(Vertex u, Vertex v) {
		
		Stack<Vertex> pathv = new Stack<Vertex>();
		LinkedList<Vertex> cycle = new LinkedList<Vertex>();
		
		while (u != v) {
			
			cycle.add(u);
			pathv.add(v);
			u = u.parent;
			v = v.parent;
		}
		
		cycle.add(u);
		
		while(!pathv.isEmpty()) {
			
			cycle.add(pathv.pop());
		}
		
		return cycle;
	}
	
	/**
	 * Resets the Graph parameters.
	 * 
	 * 
	 * 
	 */
	private void resetGraph() {
		
		for (Vertex v : g) {			
			
			v.parent = null;
			v.seen = false;
			v.distance = -1;
		}
	}
	
	/**
	 * Checks if there is a cycle of odd length in the given list of vertices which are in same level 
	 * during breadth first search.
	 * 
	 * 
	 * @param vertices
	 * @return
	 */
	
	private List<Vertex> checkAndFindOddLengthCycle(Queue<Vertex> vertices) {
		
		
		for(Vertex v : vertices) {
			
			for(Edge e : v.Adj) {
				
				Vertex vertex = e.otherEnd(v);
				
				if (vertex.distance == v.distance) {

					return getAllVerticesOfCycle(v, vertex);
				}
			}
		}
		
		return null;
	}
	
	/**
	 * Finds an odd length cycle in a given graph using breadth first search logic.
	 * while during BFS if there are two nodes in the same level having an edge between them, then
	 * there is an odd length cycle which is obtained by getting all the vertices in the BFS tree up until the lowest
	 * common ancestor else return null;
	 * 
	 */
	
	public List<Vertex> oddLengthCycle() {
		
		resetGraph();
		
		for ( Vertex vertex : g) {
			
			if (!vertex.seen) {

				int level = 0;
			
				vertex.parent = null;
				vertex.seen = true;
				vertex.distance = level;
				Queue<Vertex> queue = new LinkedList<Vertex>();
				queue.add(vertex);
				
				
				while(!queue.isEmpty()) {
					
					int n=queue.size();

					level = level + 1;
					
					for(int i=0; i<n; i++) {
						
						Vertex v = queue.poll();
			
						for (Edge e : v.Adj) {
							
							Vertex u = e.otherEnd(v);
							
							if (!u.seen) {
								
								u.parent = v;
								u.seen = true;
								u.distance = level;

								queue.add(u);
							}
						}
					}
					
					List<Vertex> cycle =  checkAndFindOddLengthCycle(queue);
					
					if (cycle != null) {
						
						return cycle;
					}
				}
				
			}
		}
		
		return null;
	}
	
	
	/**
	 * Driver function
	 * 
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
		try {
			
			FindOddLengthCycle graph = new FindOddLengthCycle();
			graph.g = Graph.readGraph(args.length > 0 ? new Scanner(new File(args[0])) : new Scanner(System.in), false);
			System.out.println("List of vertices in an odd length cycle of given graph : " + graph.oddLengthCycle());
			
		} catch (Exception e) {
			
			System.out.println(e.toString());
		}
	}
}
