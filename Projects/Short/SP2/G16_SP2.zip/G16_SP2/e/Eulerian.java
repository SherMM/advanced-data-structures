import java.io.File;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 * This class implements the logic to find if the Graph is connected or if the Graph is Eulerian or not.
 * 
 * 
 * 
 * @author G16
 *
 */


public class Eulerian {

	Graph g;

	/**
	 * reset the graph parameters.
	 * 
	 * 
	 * 
	 */
	
	
	private void resetGraph() {

		for (Vertex v : g) {

			v.parent = null;
			v.seen = false;
			v.distance = 0;
		}
	}

	
	/**
	 * Checks if the graph is connected by doing a BFS and checking if the number of visited nodes is equal 
	 * to the total number of nodes in the graph.
	 * 
	 * 
	 * 
	 * @return
	 */
	public boolean isGraphConnected() {
		
		int componentSize = 0;
		Vertex vertex = g.verts.get(1);
		Queue<Vertex> queue = new LinkedList<Vertex>();

		vertex.seen = true;
		queue.add(vertex);
		
		while (!queue.isEmpty()) {
			
			Vertex v = queue.poll();
			componentSize += 1;
						
			for(Edge e : v.Adj) {
				
				Vertex u = e.otherEnd(v);
				
				if (!u.seen) {
					
					u.seen = true;
					queue.add(u);
				}
			}
		}

		return (componentSize == (g.verts.size() - 1));
	}
	
	/**
	 * Checks if the given graph is Eulerian or Connected or not.
	 * 
	 * 
	 * 
	 * 
	 * @return
	 */

	public String testEulerian() {

		resetGraph();

		if (!isGraphConnected()) {
			
			return "Graph is not connected.";
		}

		LinkedList<Vertex> verticesWithOddDegree = new LinkedList<Vertex>();
		
		for (Vertex v : g) {

			if (v.Adj.size() % 2 == 1) {

				verticesWithOddDegree.add(v);
			}
		}
		
		if (verticesWithOddDegree.size() == 0) {
			
			return "Graph is Eulerian.";
		} else if (verticesWithOddDegree.size() == 2) {
			
			return "Graph has an Eulerian path between vertices " + verticesWithOddDegree.get(0) + " amd " + 
					verticesWithOddDegree.get(1) + ".";
		} else {
			
			return "Graph is not Eulerian. It has " + verticesWithOddDegree.size() + " vertices of odd degree.";
		}
	}
	
	/**
	 * Driver function
	 * 
	 * 
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		try {

			Eulerian graph = new Eulerian();
			graph.g = Graph.readGraph(args.length > 0 ? new Scanner(new File(args[0])) : new Scanner(System.in), false);
			System.out.println(graph.testEulerian());

		} catch (Exception e) {

			System.out.println(e.toString());
		}
	}
}
