Problem statement:
------------------

 Write a function that outputs one of
   the messages that applies to the given graph.

   void testEulerian(Graph g) { ... }

   Possible outputs:

   Graph is Eulerian.
   Graph has an Eulerian Path between vertices ?? and ??.
   Graph is not connected.
   Graph is not Eulerian.  It has ?? vertices of odd degree.

   
Solution:
---------

   Algorithm: 
   ----------
   
   A graph G is called Eulerian if it is connected and the degree of
   every vertex is an even number.  It is known that such graphs have a
   cycle (not simple) that goes through every edge of the graph
   exactly once.  A connected graph that has exactly 2 vertices of odd
   degree has an Eulerian path

The following class has been implemented for performing the above algorithm.

Eulerian.java (this class requires Graph, Vertex and Edge Classes.)

Input:
------

Input graph can be provided as either as file name in command line argument or throught console using Graph.readgraph function format.

Sample Output:
--------------

Graph is Eulerian.

Test Results:
--------------

Test case #1: (If the entire graph is of only one node)
-------------

1 0

Graph is Eulerian.


Test case #2: (If the entire graph is only one node and a cycle pointing to itself)
-------------

1 1
1 1 1

Graph is Eulerian.

Test case #3: (If the graph is disconnected)
-------------
4 3
1 2 1
2 3 1
3 1 1

Graph is not connected.

Test case #4: (If the graph is not Eulerian)
-------------

4 6
1 2 1
2 3 1
3 4 1
4 1 1
1 3 1
2 4 1

Graph is not Eulerian. It has 4 vertices of odd degree.

Test case #5: (If the graph is Eulerian)
-------------

4 4
1 2 1
2 3 1
3 4 1
4 1 1

Graph is Eulerian.

Test case #6: (If the graph has an Eulerian path)
-------------

5 4
1 2 1
1 3 1
2 4 1
3 5 1
4 5 1

Graph has an Eulerian path between vertices 4 amd 5.
