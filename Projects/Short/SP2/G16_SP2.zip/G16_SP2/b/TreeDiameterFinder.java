import java.io.File;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 * 
 * The Program to find the diameter of the tree.
 * 
 * 
 * @author G16
 *
 */
public class TreeDiameterFinder {

	public Graph g;

	/**
	 * Resets the parameters of the vertices in the graph
	 * 
	 * 
	 * 
	 */
	private void resetGraph() {
		
		for (Vertex v : g) {			

			v.seen = false;
			v.distance = 0;
		}
	}
	
	
	/**
	 * Function which finds the vertex that is farthest from a given vertex.
	 * returns null if the given input is not a tree.
	 * 
	 * @param u
	 * @return
	 */
	
	private Vertex findVertexWithMaxDistance(Vertex u) {
		
		int distance = 0;
		int componentSize = 0;
		Vertex vertexWithMaxDistance = u;
		resetGraph();
		
		Queue<Vertex> queue = new LinkedList<Vertex>();
		
		if (g.verts.size() == 1) { //return null if graph is empty;
			
			return null;
		}
		
		u.distance = 0;
		queue.add(u);
		
		while(!queue.isEmpty()) {
			
			Vertex vertex = queue.poll();

			vertex.seen = true;
			componentSize += 1;
			
			for (Edge e : vertex.Adj) {
				
				Vertex v = e.otherEnd(vertex);
				
				if (!v.seen) {
					
					v.distance = vertex.distance + 1;
					v.parent = vertex;
					queue.add(v);
					
					if (distance < v.distance) {
						
						distance = v.distance;
						vertexWithMaxDistance = v;
					}
				} else if (v != vertex.parent) { //return null if graph has a cycle

					return null;
				}
			} 

		}
		
		
		if (componentSize != g.verts.size() - 1) { // return null if graph is disconnected
			
			return null;
		}
		
		return vertexWithMaxDistance;
	}
	
	/**
	 * Function which finds the diameter of the tree
	 * returns -1 if the input is not a tree. 
	 * 
	 * 
	 * @return Diameter
	 */
	
	public int Diameter() {
		
		if (g.verts.size() == 0) {
			
			return 0;
		}
		
		 Vertex vertexWithMaxDistance = findVertexWithMaxDistance(g.verts.get(1));
		 
		 if (vertexWithMaxDistance == null) {
			 
			 return -1;
		 }
		 
		 vertexWithMaxDistance = findVertexWithMaxDistance(vertexWithMaxDistance);

		 return vertexWithMaxDistance.distance;
	}
	
	/**
	 * Main Driver Function
	 * 
	 * 
	 * @param args
	 */
	
	public static void main(String[] args) {
		try {
			
			TreeDiameterFinder graph = new TreeDiameterFinder();
			graph.g = Graph.readGraph(args.length > 0 ? new Scanner(new File(args[0])) : new Scanner(System.in), false);
			System.out.println("Diameter of the given tree is: " + graph.Diameter());
			
		} catch (Exception e) {
			
			System.out.println(e.toString());
		}
	}
}
