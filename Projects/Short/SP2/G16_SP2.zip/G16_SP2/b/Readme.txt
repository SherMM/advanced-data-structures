Problem statement:
------------------

Given an unrooted tree as input, find its Diameter (Maximum distance between any two nodes of the tree.)

   
Solution:
---------

   Algorithm: 
   ----------
   
   1. Run BFS from an arbitrary node as root.
   2. Select a node Z with maximum distance from the first BFS.
   3. Run a second BFS with Z as root.
   4. The diameter of the tree is the maximum distance to any node from Z in BFS 2.

The following class has been implemented for performing the above algorithm.

TreeDiameterFinder.java (this class requires Graph, Vertex and Edge Classes.)

Input:
------

Input graph can be provided as either as file name in command line argument or throught console using Graph.readgraph function format.

Sample Output:
--------------

Diameter of the given tree is: 6

Test Results:
--------------

Test case #1: (If the entire graph is of only one node)
-------------

1 0

Diameter of the given tree is: 0


Test case #2: (If the entire graph is only one node and a cycle pointing to itself)
-------------

1 1
1 1 1

Diameter of the given tree is: -1

Test case #3: (If the graph is disconnected)
-------------
5 3
1 2 1
2 3 1
2 4 1

Diameter of the given tree is: -1

Test case #4: (If the graph has a cycle)
-------------

4 4
1 2 1
1 3 1
2 4 1
3 4 1

Diameter of the given tree is: -1

Test case #5: (If the graph is a tree)
-------------

11 10
1 2 1
1 3 1
2 4 1
2 5 1
3 7 1
3 10 1
5 6 1
5 11 1
7 8 1
7 9 1


Diameter of the given tree is: 6
