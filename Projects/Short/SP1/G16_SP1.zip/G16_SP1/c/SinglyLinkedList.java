import java.util.ArrayList;

/** 
 *  
 *  Singly linked list: Base version taken from link: http://www.utdallas.edu/~rbk/teach/2016s/java/fSinglyLinkedList.java.txt
 *  
 *  Added multiUnzip functions to the base version of the code.
 *
 *  @author rbk, G16
 */

public class SinglyLinkedList<T> {
    
	public class Entry {
      
		T element;
        Entry next;

        Entry(T x, Entry nxt) {
            
        	element = x;
            next = nxt;
        }
    }

    Entry header, tail;
    int size;

    SinglyLinkedList() {
        
    	header = new Entry(null, null);
        tail = null;
        size = 0;
    }

    void add(T x) {
       
    	if(tail == null) {
            
    		header.next = new Entry(x, header.next);
            tail = header.next;
        } else {
            
        	tail.next = new Entry(x, null);
            tail = tail.next;
        }
	    size++;
    }

    void printList() {
       
    	Entry x = header.next;
        
    	while(x != null) {
        
    		System.out.print(x.element + " ");
            x = x.next;
        }
        
    	System.out.println();
    }

    void unzip() {
    	
		if(size < 3) {  // Too few elements.  No change.
		    
			return;
		}
	
		Entry tail0 = header.next;
		Entry head1 = tail0.next;
		Entry tail1 = head1;
		Entry c = tail1.next;
		int state = 0;
	
		// Invariant: tail0 is the tail of the chain of elements with even index.
		// tail1 is the tail of odd index chain.
		// c is current element to be processed.
		// state indicates the state of the finite state machine
		// state = i indicates that the current element is added after taili (i=0,1).
		
		while(c != null) {
			
		    if(state == 0) {
				
		    	tail0.next = c;
				tail0 = c;
				c = c.next;
		    } else {
		    	
				tail1.next = c;
				tail1 = c;
				c = c.next;
		    }
		    
		    state = 1 - state;
		}
		
		tail0.next = head1;
		tail1.next = null;
    }
    
    /**
     * Rearranges elements of a singly linked list by chaining
     * together elements that are k apart. If the list has elements
     * 1..10 in order, after multiUnzip(3), the elements will be
     * rearranged as: 1 4 7 10 2 5 8 3 6 9.  Instead if we call
     * multiUnzip(4), the list 1..10 will become 1 5 9 2 6 10 3 7 4 8.
       
     * The approach in unzip functionality has been extend to unzip list into k chains
     * 
     * 
     * @param k
     */
    
    
    void multiUnzip(int k) {
    	
    	if (size < k) {
    		
    		return;
    	}
    	
    	ArrayList<Entry> heads = new ArrayList<Entry>(k);
    	ArrayList<Entry> tails = new ArrayList<Entry>(k);
    	Entry c = header.next;
    	int state = 0;
    	
    	// Invariant: heads(k), tails(k) are the head and tail pointers of kth chain.
    	// c is the current element to be processed.
    	// state indicates the current chain index that needs to be processed.
    	
    	for(int i=0; i<k; i++) {
    		
    		heads.add(c);
    		tails.add(c);
    		c = c.next;
    	}

    	while (c != null) {
    		
    		tails.get(state).next = c;
    		tails.set(state, c);
    		c = c.next;
    		state = (state + 1) % k;
    	}
    	
    	for (int i=1; i<k; i++) {
    		
    		tails.get(i-1).next = heads.get(i);
    	}
    	
    	tails.get(k-1).next = null;
    }

    

    public static void main(String[] args) {
        int n = 10;
        int k=4;
        
        if(args.length > 0) {
        	
            n = Integer.parseInt(args[0]);
        }

        SinglyLinkedList<Integer> lst = new SinglyLinkedList<>();
        
        for(int i=1; i<=n; i++) {
            lst.add(new Integer(i));
        }
        System.out.println("Input: ");
        lst.printList();
        lst.multiUnzip(k);
        System.out.println("Output " + "(k=" + k + "): ");
        lst.printList();
    }
}
