Problem statement:
------------------

 Write the Merge sort algorithm that works on linked lists.
   
Solution:
---------

The following class has been implemented for performing addition and subtraction of large numbers.

SortableList.java (this is extended from SinglyLinkedList class whose java file is attached.)

The class implements the following functions:

No.        Function Name                           Description                              Parameters
---       ----------------        --------------------------------------------           ------------------
1.           mergeSort              sorts the list using merge sort algorithm                  none
2.           merge                  implements the merging of two sorted lists                 the second list that has to be merged with calling list.


Inputs have to be generated in main function. Sample input has been provided in the code.

Complexity: Time - O(nlgn); Space O(lgn) for recursive call stack.


Sample Output:
--------------

Input list: 
539 885 839 386 342 438 750 371 225 41 383 293 698 882 643 831 670 319 99 446 328 682 730 444 623 73 464 674 71 541 
Sorted list: 
41 71 73 99 225 293 319 328 342 371 383 386 438 444 446 464 539 541 623 643 670 674 682 698 730 750 831 839 882 885 