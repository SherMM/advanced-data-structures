import java.util.Random;

/**
 * This class implements merge sort algorithm using list.
 * 
 * 
 * @author G16
 *
 */

public class SortableList<T extends Comparable<? super T>> extends SinglyLinkedList<T> {
   
	public void merge(SortableList<T> l2) {

		Entry currentLeft = this.header.next;
		Entry currentRight = l2.header.next;
		Entry current = this.header;
		
		while (currentLeft != null && currentRight != null) {
			
			int compare = currentLeft.element.compareTo(currentRight.element);
			
			if (compare == 0) {
				

				Entry tempLeft = currentLeft;
				Entry tempRight = currentRight;
				
				currentLeft = currentLeft.next;
				currentRight = currentRight.next;
				current.next = tempLeft;
				current = current.next;
				current.next = tempRight;
				current = current.next;
				
			} else if (compare < 0){

				current.next = currentLeft;
				current = current.next;
				currentLeft = currentLeft.next;
			} else {
				
				current.next = currentRight;
				current = current.next;				
				currentRight = currentRight.next;
			}
		}
		
		if (currentLeft != null) {
			
			current.next = currentLeft;
		} 
		
		if (currentRight != null) {
			
			current.next = currentRight;
		}
    }

    void mergeSort() {

    	Entry current = this.header.next;
    	Entry middle = this.header.next;
    	
    	while (current.next != null && current.next.next != null) {
    		
    		current = current.next;
    		current = current.next;
    		middle = middle.next;
    	}
    	
    	if (middle == this.header.next) {

    		if (tail.element.compareTo(middle.element) < 0) {
    			
    			T temp = middle.element;
    			middle.element = tail.element;
    			tail.element = temp;
    			
    			//this.printList();
    		}
    		
    	} else {
    		
    		SortableList<T> left = this;
    		SortableList<T> right = new SortableList<T>();
    		right.header.next = middle.next;
    		right.tail = this.tail;
    		left.tail = middle;
    		middle.next = null;
    	
    		
    		left.mergeSort();
    		right.mergeSort();
    		left.merge(right);
    	}
    }

    public static<T extends Comparable<? super T>> void mergeSort(SortableList<T> lst) {

    	lst.mergeSort();
    }

    public static void main(String[] args) {

    	int size = 30;
    	Random random = new Random();
    	SortableList<Integer> list = new SortableList<Integer>();
    	for(int i=0; i<size; i++) {
    	
    		list.add(random.nextInt(size*size));
    	}
   
    	System.out.println("Input list: ");
    	list.printList();
    	
    	list.mergeSort();
    	
    	System.out.println("Sorted list: ");
    	list.printList();
    }
}