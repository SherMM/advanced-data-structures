import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * This class implements addition and subtraction of two very large integers whose digits are reversed and stored
 * as lists.
 * 
 * @author G16
 *
 */


public class LargeInt {

	/**
	 * 
	 * Returns z = x + y.  Numbers are stored using base b. The "digits" are stored in the list with the least
	 * significant digit first.  For example, if b = 10, then the number 709 will be stored as 9 -> 0 -> 7.
	 * 
	 * 
	 * @param x
	 * @param y
	 * @param z
	 * @param b
	 */
	 public static void add(List<Integer> x, List<Integer>  y,List<Integer> z, int b) {
		   
		 Iterator<Integer> iteratorX = x.iterator();
		 Iterator<Integer> iteratorY = y.iterator();
		 int digitX = 0, digitY = 0, sum = 0, carry = 0;
		 
		 z.clear();
		 
		 while (iteratorX.hasNext() || iteratorY.hasNext()) {
			 
			 digitX = iteratorX.hasNext() ? iteratorX.next() : 0;
			 digitY = iteratorY.hasNext() ? iteratorY.next() : 0;
			 
			 sum = (digitX + digitY + carry);
			 
			 if (sum >= b) {
				 
				 carry = 1;
				 sum = sum % b;
			 } else {
				 
				 carry = 0;
			 }
			 
			 z.add(sum);
		 }
		 
		 if (carry == 1) {
			 
			 z.add(1);
		 }
	 }
	 

	 /**
	  * Returns z = x - y.  Numbers are stored using base b. x should be greater than y.
	  * 
	  * 
	  * @param x
	  * @param y
	  * @param z
	  * @param b
	  */

     public static void subtract(List<Integer> x, List<Integer>  y,List<Integer> z, int b) {

    	 Iterator<Integer> iteratorX = x.iterator();
		 Iterator<Integer> iteratorY = y.iterator();
		 int digitX = 0, digitY = 0, difference = 0, borrow = 0;
		 
		 z.clear();
		 
		 while (iteratorX.hasNext()) {
			 
			 digitX = iteratorX.hasNext() ? iteratorX.next() : 0;
			 digitY = iteratorY.hasNext() ? iteratorY.next() : 0;
			 
			 difference = digitX - digitY - borrow;
			 
			 if (difference >= 0) {
					
				 borrow = 0;
			 } else {
				 
				 borrow = 1;
				 difference += b;
			 }

			 z.add(difference);
		 }
	 }
     
     /**
      * 
      * Driver Function
      * 
      * @param args
      */
     public static void main(String[] args) {
    	 
    	 int base = 10;
    	 LinkedList<Integer> num1 = new LinkedList<Integer>();
    	 LinkedList<Integer> num2 = new LinkedList<Integer>();
    	 LinkedList<Integer> result = new LinkedList<Integer>();
    	 
    	 /*
    	 base = 10;
    	 num1.add(2);
    	 num1.add(1);
    	 num1.add(1);
    	 num2.add(0);
    	 num2.add(2);
    	 */

    	 base = 2;
    	 num1.add(1);
    	 num1.add(1);
    	 num1.add(1);
    	 num2.add(0);
    	 num2.add(1);
    	 
    	 System.out.println("Base          : " + base);
    	 System.out.println("First number  : " + num1);
    	 System.out.println("Second number : " + num2);
    	 
    	 result.clear();
    	 add(num1, num2, result, base);
    	 System.out.println("On addition   : " + result);
    	 
    	 result.clear();
    	 subtract(num1, num2, result, base);
    	 System.out.println("On Subtraction: " + result);
     }
}
