Problem statement:
------------------

 Extend the "unzip" algorithm to "multiUnzip" on the SinglyLinkedList class
   
Solution:
---------

The following class has been implemented for performing addition and subtraction of large numbers.

SinglyLinkedList.java

The class implements the following functions:

No.        Function Name                           Description                              Parameters
---       ----------------        --------------------------------------------           ------------------               
1.           multiunzip           Splits and Groups the elements based on specified.   k - no of splits to be made in the list.
                                  length.


Inputs have to be generated in main function. Sample input has been provided in the code.

Complexity: Time - O(n); Space O(k) for k pairs of header and tail nodes.


Sample Output:
--------------

Input: 
1 2 3 4 5 6 7 8 9 10 
Output (k=4): 
1 5 9 2 6 10 3 7 4 8 
