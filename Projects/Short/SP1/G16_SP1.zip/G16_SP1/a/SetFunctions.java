import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * The following class implements the set functions namely union, intersection and difference of two lists.
 * 
 * @author G16
 *
 */
public class SetFunctions {

	private static<T extends Comparable<? super T>>
	T next(Iterator<T> iterator) {
		
		return iterator.hasNext() ? iterator.next() : null;
	}
	/**
	 * Returns elements common to l1 and l2, in sorted order. outList is an empty list created by the calling
       program and passed as a parameter.
	 * 
	 * 
	 * @param l1
	 * @param l2
	 * @param outList
	 */
	
	public static<T extends Comparable<? super T>>
    void intersect(List<T> l1, List<T> l2, List<T> outList) {

		Iterator<T> iterator1 = l1.iterator();
		Iterator<T> iterator2 = l2.iterator();
		
		T node1 = next(iterator1);
		T node2 = next(iterator2);
		
		while(node1 != null && node2 != null) {
			
			int compare = node1.compareTo(node2);
			
			if (compare == 0) {
				
				outList.add(node1);
				node1 = next(iterator1);
				node2 = next(iterator2);
			} else if(compare < 0) {
				
				node1 = next(iterator1);
			} else {
				
				node2 = next(iterator2);
			}
		}		
	}
	
	/**
	 * Returns the union of l1 and l2, in sorted order. Output is a set, so it will have no duplicates.
	 * 
	 * @param l1
	 * @param l2
	 * @param outList
	 */

	public static<T extends Comparable<? super T>>
	    void union(List<T> l1, List<T> l2, List<T> outList) {

		
		Iterator<T> iterator1 = l1.iterator();
		Iterator<T> iterator2 = l2.iterator();
		
		T node1 = next(iterator1);
		T node2 = next(iterator2);
		
		while(node1 != null && node2 != null) {
			
			int compare = node1.compareTo(node2);
			
			if (compare == 0) {
				
				outList.add(node1);
				node1 = next(iterator1);
				node2 = next(iterator2);
			} else if(compare < 0) {
				
				outList.add(node1);
				node1 = next(iterator1);
			} else {
				
				outList.add(node2);
				node2 = next(iterator2);
			}
		}		
		
		while (node1 != null) {
			
			outList.add(node1);
			node1 = next(iterator1);
		}
		
		
		while (node2 != null) {
			
			outList.add(node2);
			node2 = next(iterator2);
		}
	}

	/**
	 * Returns l1 - l2 (i.e, items in l1 that are not in l2), in sorted order. 
	 * Output is a set, so it will have no duplicates.
	 * 
	 * @param l1
	 * @param l2
	 * @param outList
	 */
	public static<T extends Comparable<? super T>>
	    void difference(List<T> l1, List<T> l2, List<T> outList) {
	   
		
		Iterator<T> iterator1 = l1.iterator();
		Iterator<T> iterator2 = l2.iterator();
		
		T node1 = next(iterator1);
		T node2 = next(iterator2);
		
		while(node1 != null && node2 != null) {
			
			int compare = node1.compareTo(node2);
			
			if (compare == 0) {
				
				node1 = next(iterator1);
				node2 = next(iterator2);
			} else if(compare < 0) {
				
				outList.add(node1);
				node1 = next(iterator1);
			} else {
				
				node2 = next(iterator2);
			}
		}		
		
		while (node1 != null) {
			
			outList.add(node1);
			node1 = next(iterator1);
		}
	}

	public static void main(String[] args) {
		
		LinkedList<Integer> list1 = new LinkedList<Integer>();
		LinkedList<Integer> list2 = new LinkedList<Integer>();
		LinkedList<Integer> outList = new LinkedList<Integer>();
		
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(6);
		list2.add(2);
		list2.add(3);
		list2.add(5);
		
		System.out.println("Input list1 : " + list1);
		System.out.println("Input list2 : " + list2);
		
		outList.clear();
		intersect(list1, list2, outList);
		System.out.println("Intersection: " + outList);
		
		outList.clear();
		union(list1, list2, outList);
		System.out.println("Union       : " + outList);
		
		outList.clear();
		difference(list1, list2, outList);
		System.out.println("difference  : " + outList);
	}
}
