Problem statement:
------------------

Given two linked lists implementing sorted sets, write functions for union, intersection, and set difference of the sets.

   
Solution:
---------

The following class has been implemented for performing union, intersection and set difference of the sorted sets.

SetFunctions.java

All of the set functions take two lists (which contain sorted set elements) and perform corresponding operations.

Input sorted sets have to be generated in main function. Sample input is present in the program code itself.


Sample Output:
--------------

Input list1 : [1, 2, 3, 6]
Input list2 : [2, 3, 5]
Intersection: [2, 3]
Union       : [1, 2, 3, 5, 6]
difference  : [1, 6]
